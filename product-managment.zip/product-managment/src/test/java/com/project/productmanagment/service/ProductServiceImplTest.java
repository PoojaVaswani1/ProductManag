package com.project.productmanagment.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.project.productmanagment.model.Product;
import com.project.productmanagment.repo.ProductRepo;
 @ExtendWith(MockitoExtension.class)
public class ProductServiceImplTest {
	@Mock
	public ProductRepo productRepo;
	
	@Mock
	public ProductService productservice;
	@InjectMocks
	public ProductServiceImpl productServiceImpl;
	
	@Test
	public void testSaveProduct() {
	    // Create a new product
	    Product product = new Product();
	    product.setCategory("phones");
	    product.setPrice(22000);
	    product.setProductName("Samsung Galaxy");
	    product.setAvaliability("Yes"); // Corrected the spelling of "Availability"
	    when(productRepo.save(product)).thenReturn(product);
	    Product savedProduct = productServiceImpl.saveProduct(product);

	    assertNotNull(savedProduct);
	    assertEquals(22000, product.getPrice()); 
	    assertEquals("phones", product.getCategory()); 
	    assertEquals("Samsung Galaxy", product.getProductName()); 
	    assertEquals("Yes", product.getAvaliability()); 
	}
	@Test
    public void testGetAllProducts() {
        
        List<Product> productList = new ArrayList<>();
        productList.add(new Product(1, "phones", 22000, "Samsung Galaxy", "Yes"));
        productList.add(new Product(2, "laptops", 1200, "Dell XPS", "Yes"));

        
        when(productRepo.findAll()).thenReturn(productList);

        List<Product> result = productServiceImpl.getAllProducts();

        assertNotNull(result);

        assertEquals(productList.size(), result.size());

        assertEquals(productList.get(0), result.get(0));
        assertEquals(productList.get(1), result.get(1));
    }

    @Test
    public void testFindById() {
        
        Product sampleProduct = new Product(1, "phones", 22000, "Samsung Galaxy", "Yes");

        when(productRepo.findById(1)).thenReturn(Optional.of(sampleProduct));

        Product result = productServiceImpl.findById(1);

        assertNotNull(result);
        assertEquals(sampleProduct, result);
    }
    
    @Test
    public void testDeleteProduct_ProductFound() {
       
        Product sampleProduct = new Product(1, "phones", 22000, "Samsung Galaxy", "Yes");
        Integer productId = 1;

        when(productRepo.findById(productId)).thenReturn(Optional.of(sampleProduct));

        String result = productServiceImpl.deleteProduct(productId);

        // Verify that the result is "found"
        assertEquals("found", result);

    }

    
}



	





	
	
	

