package com.project.productmanagment.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String productName;
	private double price;
	private String category;
	private String avaliability;
	
	
	public Product() {
		super();
	}
	public Integer getId() {
		return id;
	}
	public Product(Integer id, String productName, double price, String category, String avaliability) {
		super();
		this.id = id;
		this.productName = productName;
		this.price = price;
		this.category = category;
		this.avaliability = avaliability;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getAvaliability() {
		return avaliability;
	}
	public void setAvaliability(String avaliability) {
		this.avaliability = avaliability;
	} 
	

}
