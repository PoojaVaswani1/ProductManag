package com.project.productmanagment.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.productmanagment.model.Product;

public interface ProductRepo extends JpaRepository<Product, Integer>{

}
