package com.project.productmanagment.service;

import java.util.List;


import com.project.productmanagment.model.Product;

public interface ProductService {
	
	
	public Product saveProduct(Product product);
	
	public String deleteProduct(Integer id);
	
	public List<Product> getAllProducts();
	
	public Product findById(Integer id);
}
